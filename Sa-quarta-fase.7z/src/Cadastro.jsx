import { useState } from 'react'
import './Home.css'





function Cadastro() {


  return (
    <>
    <div className='index'>
      <h1>Cadastro</h1>
      </div>
    </>
  )
}

export default Cadastro
