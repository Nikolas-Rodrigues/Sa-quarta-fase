import { useState } from 'react'
import './Home.css'





function HFunc() {


  return (
    <div className='index'>
      <h1>H func</h1>
    </div>
  )
}

export default HFunc
