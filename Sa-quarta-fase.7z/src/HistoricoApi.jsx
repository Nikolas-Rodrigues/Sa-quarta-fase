import { useState } from 'react'
import './Home.css'





function HApi() {


  return (
    <div className='index'>
      <h1>EPIS</h1>
      </div>
  )
}

export default HApi
