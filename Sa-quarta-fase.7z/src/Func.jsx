import { useState } from 'react'
import './Home.css'





function Func() {


  return (
    <div className='index'>
      <h1>Funcionarios</h1>
    </div>
  )
}

export default Func
