function listar() {
    console.log('SEXO ENTRE HETERO QUENTE FESTA RED PILL')
}
console.log('Foi');